jQuery( document ).ready( ( $ ) => {

	'use strict';

	window.WC_Authorize_Net_My_Payment_Methods_Handler = window.SV_WC_Payment_Methods_Handler_v5_10_12;

	$( document.body ).trigger( 'wc_authorize_net_my_payment_methods_handler_loaded' );

} );
