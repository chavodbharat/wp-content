jQuery( document ).ready( ( $ ) => {

	'use strict';

	window.WC_Authorize_Net_Apple_Pay_Handler = window.SV_WC_Apple_Pay_Handler_v5_10_12;

	$( document.body ).trigger( 'wc_authorize_net_apple_pay_handler_loaded' );

} );
